# Wor**l**dle

Play this geographical wordle here: https://worldle.teuteuf.fr !

## Resources used:

- Countries with long/lat => https://developers.google.com/public-data/docs/canonical/countries_csv
- Country images => https://github.com/djaiss/mapsicon
- French country names => https://fr.wikipedia.org/wiki/ISO_3166
